create table discussions
(
    discussion_id    int                                   not null
        primary key,
    title            varchar(256)                          not null,
    description      text                                  not null,
    due_date         date                                  not null,
    discussion_owner varchar(50)                           not null,
    creation_date    datetime    default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP,
    status           varchar(20) default 'Open'            not null,
    constraint discussions_ibfk_1
        foreign key (discussion_owner) references users (email)
);

create index discussion_owner
    on discussions (discussion_owner);

INSERT INTO final_project.discussions (discussion_id, title, description, due_date, discussion_owner, creation_date, status) VALUES (1, 'What should we eat on Friday?', 'We want to invite you to a dinner on Friday for celebrating the end of the lockdown. Please share your favorite food :)', '2021-03-17', 'basslir@post.bgu.ac.il', '2021-03-19 13:34:57', 'Final Voting');
INSERT INTO final_project.discussions (discussion_id, title, description, due_date, discussion_owner, creation_date, status) VALUES (2, 'Where should we go hiking?', 'We want to have a trip on 14.05.21.
Please share your options with us.', '2021-03-31', 'basslir@post.bgu.ac.il', '2021-03-19 12:55:47', 'Final Voting');
INSERT INTO final_project.discussions (discussion_id, title, description, due_date, discussion_owner, creation_date, status) VALUES (3, 'what do we want to eat on the ON FIRE ?', 'i want to know what do you want to eat to know which things to buy thanl you guysss love you all', '2021-03-22', 'basslir@post.bgu.ac.il', '2021-03-19 12:37:44', 'Open');
INSERT INTO final_project.discussions (discussion_id, title, description, due_date, discussion_owner, creation_date, status) VALUES (4, 'what do you want on student day?', 'we want to let you choose what to do on student day! ', '2021-05-01', 'basslir@post.bgu.ac.il', '2021-03-21 19:27:00', 'Voting');