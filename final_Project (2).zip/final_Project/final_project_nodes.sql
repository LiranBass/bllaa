create table nodes
(
    node_id       int auto_increment,
    discussion_id int           not null,
    parent_node   int           null,
    node_content  text          not null,
    node_owner    varchar(50)   not null,
    node_level    int           null,
    node_score    int default 0 null,
    primary key (node_id, discussion_id),
    constraint nodes_ibfk_1
        foreign key (node_owner) references users (email),
    constraint nodes_ibfk_2
        foreign key (discussion_id) references discussions (discussion_id),
    constraint nodes_ibfk_3
        foreign key (parent_node) references nodes (node_id)
);

create index comment_owner
    on nodes (node_owner);

create index discussion_id
    on nodes (discussion_id);

create index parent_comment
    on nodes (parent_node);

INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (74, 1, null, 'What should we eat on Friday?', 'basslir@post.bgu.ac.il', 0, 18);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (75, 2, null, 'Where should we go hiking?', 'basslir@post.bgu.ac.il', 0, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (76, 1, 74, 'Pizza', 'basslir@post.bgu.ac.il', 1, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (77, 1, 74, 'Sushi', 'basslir@post.bgu.ac.il', 1, 5);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (78, 1, 74, 'Burger', 'basslir@post.bgu.ac.il', 1, 10);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (79, 1, 76, 'With Onion', 'basslir@post.bgu.ac.il', 2, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (80, 1, 76, 'With Olives', 'basslir@post.bgu.ac.il', 2, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (81, 1, 79, 'With mushrooms', 'boazki@post.bgu.ac.il', 3, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (82, 1, 77, 'With Avocado', 'basslir@post.bgu.ac.il', 2, 5);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (83, 1, 77, 'With sweet potato', 'basslir@post.bgu.ac.il', 2, 5);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (84, 1, 83, 'and salmon', 'basslir@post.bgu.ac.il', 3, 5);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (85, 1, 78, 'With egg', 'basslir@post.bgu.ac.il', 2, 75);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (91, 1, 74, 'asado!', 'guest@guest.guest', 1, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (92, 3, null, 'what do we want to eat on the ON FIRE ?', 'basslir@post.bgu.ac.il', 0, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (93, 2, 75, 'nahal saar', 'basslir@post.bgu.ac.il', 1, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (94, 2, 75, '!mitzpe ramon', 'basslir@post.bgu.ac.il', 1, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (96, 2, 75, 'TEL AVIV YAM!', 'basslir@post.bgu.ac.il', 1, 100);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (97, 2, 96, 'shake in tel aviv', 'basslir@post.bgu.ac.il', 2, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (104, 4, null, 'what do you want on student day?', 'basslir@post.bgu.ac.il', 0, 62);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (105, 4, 104, 'parties!', 'basslir@post.bgu.ac.il', 1, 22);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (106, 4, 104, 'Food festival', 'basslir@post.bgu.ac.il', 1, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (107, 4, 104, 'Shows', 'basslir@post.bgu.ac.il', 1, 40);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (108, 4, 104, 'Gifts', 'basslir@post.bgu.ac.il', 1, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (109, 4, 105, 'Dance Party!', 'basslir@post.bgu.ac.il', 2, 13);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (110, 4, 109, 'Baraka', 'basslir@post.bgu.ac.il', 3, 13);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (111, 4, 109, 'Manga is the best!', 'basslir@post.bgu.ac.il', 3, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (112, 4, 107, 'artists', 'basslir@post.bgu.ac.il', 2, 40);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (113, 4, 112, 'omer adam', 'basslir@post.bgu.ac.il', 3, 40);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (114, 4, 112, 'eden ben zaken', 'basslir@post.bgu.ac.il', 3, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (115, 4, 105, 'headphones', 'basslir@post.bgu.ac.il', 2, 9);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (116, 4, 106, 'vegeterian', 'basslir@post.bgu.ac.il', 2, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (117, 4, 112, 'noa kirel', 'basslir@post.bgu.ac.il', 3, 0);
INSERT INTO final_project.nodes (node_id, discussion_id, parent_node, node_content, node_owner, node_level, node_score) VALUES (118, 4, 107, 'students show', 'basslir@post.bgu.ac.il', 2, 0);