create table users
(
    email       varchar(50) not null
        primary key,
    first_name  varchar(30) not null,
    last_name   varchar(30) not null,
    password    varchar(15) not null,
    birth_date  date        not null,
    city        varchar(30) not null,
    user_tokens int         null
);

INSERT INTO final_project.users (email, first_name, last_name, password, birth_date, city, user_tokens) VALUES ('basslir@post.bgu.ac.il', 'Liran', 'Bass', 'tesla', '1990-01-08', 'Beer Sheva', 5160);
INSERT INTO final_project.users (email, first_name, last_name, password, birth_date, city, user_tokens) VALUES ('boazki@post.bgu.ac.il', 'Boaz', 'Kishoni', '12345', '1993-03-26', 'Tel aviv', 1000);
INSERT INTO final_project.users (email, first_name, last_name, password, birth_date, city, user_tokens) VALUES ('guest@guest.guest', 'Guest', '', '12345', '2021-03-19', '', 0);
INSERT INTO final_project.users (email, first_name, last_name, password, birth_date, city, user_tokens) VALUES ('linoilutati@gmail.com', 'Linoy', 'Lutati', '12341234', '1994-01-23', 'Beer Sheva', 5000);
INSERT INTO final_project.users (email, first_name, last_name, password, birth_date, city, user_tokens) VALUES ('tesla@tesla.com', 'elon ', 'msk', 'tesla', '1976-03-04', 'maadim', null);